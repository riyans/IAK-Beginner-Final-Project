package com.example.riyans.biodata;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class IsiBiodata extends Activity{
    private OperasiDatabase oprDatabase = null;
    private SQLiteDatabase db = null;
    private EditText txtnim;
    private EditText txtnama;
    private EditText txtalamat;
    private Button btnsimpan;
    private Boolean data_baru;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        String nim ="";
        String nama ="";
        String alamat ="";

        super.onCreate(savedInstanceState);
        setContentView(R.layout.isibiodata);

        oprDatabase = new OperasiDatabase(this);
        db = oprDatabase.getWritableDatabase();
        oprDatabase.createTable(db);

        Intent sender = getIntent();
        String status = sender.getExtras().getString("status");
        if(status.equalsIgnoreCase("baru")){
            data_baru = true;
        } else
        {
            data_baru = false;
            nim = sender.getExtras().getString("nim");
            nama = sender.getExtras().getString("nama");
            alamat = sender.getExtras().getString("alamat");
        }

        txtnim = (EditText) findViewById(R.id.txtnim);
        txtnim.setText(nim);
        txtnama = (EditText) findViewById(R.id.txtnama);
        txtnama.setText(nama);
        txtalamat = (EditText) findViewById(R.id.txtalamat);
        txtalamat.setText(alamat);
        btnsimpan = (Button) findViewById(R.id.btnsimpan);
        if(data_baru==true)
            btnsimpan.setText("Simpan");
        else
            btnsimpan.setText("Edit");
        btnsimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                simpandata();
            }
        });
    }
    private void simpandata(){
        String[] data = new String[]{
                txtnim.getText().toString(),
                txtnama.getText().toString(),
                txtalamat.getText().toString()
        };
        if(data_baru==true) {
            oprDatabase.insertBiodata(db, data);
            txtnim.setText("");
            txtnama.setText("");
            txtalamat.setText("");
        }
        else if(data_baru==false){
            oprDatabase.updateBiodata(db, data);
            finish();
        }

    }
    public void onDestroy() {
        super.onDestroy();
        db.close();
    }
}